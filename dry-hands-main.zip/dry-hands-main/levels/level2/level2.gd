extends BaseLevel
